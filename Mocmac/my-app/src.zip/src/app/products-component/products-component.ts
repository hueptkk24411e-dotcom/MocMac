import { Component, computed, effect, inject, signal, untracked } from '@angular/core';
import { toSignal } from '@angular/core/rxjs-interop';
import { ActivatedRoute, Router } from '@angular/router';
import { map } from 'rxjs';
import { CartService } from '../cart.service';
import {
  ArrayKey, Filters, PRED, ProductItem, ProductsService, defaultFilters, fromParams, matchFilters, toParams,
} from '../products.service';

interface Opt { v: string; l: string; n: number; icon?: string; }
const PAGE_SIZE = 12;
const ARR: ArrayKey[] = ['cat', 'type', 'region', 'price', 'ocop', 'heri', 'occ', 'status', 'months'];

@Component({
  selector: 'app-products-component',
  standalone: false,
  templateUrl: './products-component.html',
  styleUrl: './products-component.css',
})
export class ProductsComponent {
  private svc = inject(ProductsService);
  private router = inject(Router);
  private route = inject(ActivatedRoute);
  cart = inject(CartService);

  all = this.svc.products;
  applied = toSignal(this.route.queryParamMap.pipe(map(fromParams)), { initialValue: defaultFilters() });
  draft = signal<Filters>(defaultFilters());
  favs = signal<Set<number>>(new Set());
  showFilters = signal(false);
  brokenImg = signal<Set<string>>(new Set());
  private imgIdx = signal<Record<number, number>>({});
  readonly tabs = ['Tất cả', 'Đặc sản', 'Thủ công mỹ nghệ', 'Cà phê - Trà', 'Sản phẩm OCOP'];
  readonly month = new Date().getMonth() + 1;
  
  // ===== KHU VỰC KHÁM PHÁ NHANH =====
  readonly quickTags = [
    'Quà Tết',
    'Đặc sản vùng miền',
    'Đồ thủ công',
    'Quà biếu đối tác',
    'Quà cưới',
    'OCOP'
  ];

  // Hai sản phẩm gợi ý dựa trên lượt đánh giá và điểm đánh giá
  topProducts = computed(() =>
    [...this.all()]
      .sort(
        (a, b) =>
          (b.reviews * 2 + b.rate * 10) -
          (a.reviews * 2 + a.rate * 10)
      )
      .slice(0, 2)
  );

  // Sản phẩm có nhiều lượt đánh giá nhất
  bestSeller = computed(() =>
    [...this.all()].sort((a, b) => b.reviews - a.reviews)[0]
  );

  // Sản phẩm có giá thấp nhất
  bestPrice = computed(() =>
    [...this.all()].sort((a, b) => a.price - b.price)[0]
  );

  // Nhấn thẻ để tìm kiếm nhanh
  quickSearch(tag: string) {
    this.draft.update(d => ({ ...d, q: tag }));
    this.go({ ...this.applied(), q: tag, page: 1 });
  }


  constructor() {
    effect(() => { const a = this.applied(); untracked(() => this.draft.set({ ...a })); });
  }

  private count(k: ArrayKey, v: string) { return this.all().filter(p => PRED[k](p, v)).length; }
  private opts(k: ArrayKey, list: [string, string, string?][]): Opt[] {
    return list.map(([v, l, icon]) => ({ v, l, icon, n: this.count(k, v) }));
  }

  catOpts = computed(() => this.opts('cat', [['Đặc sản', 'Đặc sản', '🥭'], ['Thủ công mỹ nghệ', 'Thủ công mỹ nghệ', '🧺'], ['Cà phê - Trà', 'Cà phê - Trà', '☕'], ['Sản phẩm OCOP', 'Sản phẩm OCOP', '⭐']]));
  typeOpts = computed(() => this.opts('type', ['Gốm', 'Mây tre đan', 'Sơn mài', 'Thổ cẩm', 'Đặc sản khô', 'Trà', 'Cà phê', 'Khác'].map(x => [x, x] as [string, string])));
  regionOpts = computed(() => this.opts('region', ['Miền Bắc', 'Miền Trung', 'Tây Nguyên', 'Miền Nam'].map(x => [x, x] as [string, string])));
  priceOpts = computed(() => this.opts('price', [['lt200', 'Dưới 200.000đ'], ['200-500', '200.000đ - 500.000đ'], ['500-1000', '500.000đ - 1.000.000đ'], ['gt1000', 'Trên 1.000.000đ']]));
  ocopOpts = computed(() => this.opts('ocop', [['3', 'OCOP 3 sao'], ['4', 'OCOP 4 sao'], ['5', 'OCOP 5 sao']]));
  heriOpts = computed(() => this.opts('heri', [['Vàng', 'Di sản Vàng'], ['Bạc', 'Di sản Bạc']]));
  occOpts = computed(() => this.opts('occ', ['Quà Tết', 'Quà cưới', 'Quà tân gia', 'Quà biếu đối tác'].map(x => [x, x] as [string, string])));
  statusOpts = computed(() => this.opts('status', [['in', 'Còn hàng'], ['pre', 'Pre-order']]));
  monthOpts = computed(() => this.opts('months', [['1-3', 'Tháng 1-3'], ['4-6', 'Tháng 4-6'], ['7-9', 'Tháng 7-9'], ['10-12', 'Tháng 10-12']]));
  provinces = computed(() => [...new Set(this.all().map(p => p.province))].sort((a, b) => a.localeCompare(b, 'vi')));
  villages = computed(() => [...new Set(this.all().map(p => p.village).filter(Boolean))].sort((a, b) => a.localeCompare(b, 'vi')));

  filtered = computed(() => {
    const f = this.applied(), m = this.month;
    const list = this.all().filter(p => matchFilters(p, f, m));
    const sorters: Record<string, (a: ProductItem, b: ProductItem) => number> = {
      popular: (a, b) => b.reviews - a.reviews,
      'price-asc': (a, b) => a.price - b.price,
      'price-desc': (a, b) => b.price - a.price,
      rating: (a, b) => b.rate - a.rate,
      newest: (a, b) => b.id - a.id,
    };
    return list.sort(sorters[f.sort] ?? sorters['popular']);
  });
  totalPages = computed(() => Math.max(1, Math.ceil(this.filtered().length / PAGE_SIZE)));
  page = computed(() => Math.min(this.applied().page, this.totalPages()));
  paged = computed(() => this.filtered().slice((this.page() - 1) * PAGE_SIZE, this.page() * PAGE_SIZE));
  pages = computed(() => Array.from({ length: this.totalPages() }, (_, i) => i + 1));

  // ---- bộ lọc nháp (sidebar) ----
  has(k: ArrayKey, v: string) { return this.draft()[k].includes(v); }
  toggle(k: ArrayKey, v: string) {
    this.draft.update(d => ({ ...d, [k]: d[k].includes(v) ? d[k].filter(x => x !== v) : [...d[k], v] }));
  }
  setField<K extends 'province' | 'village' | 'q' | 'rate'>(k: K, v: Filters[K]) { this.draft.update(d => ({ ...d, [k]: v })); }
  toggleNow() { this.draft.update(d => ({ ...d, now: !d.now })); }

  // ---- đẩy lên URL ----
  private go(f: Filters) { this.router.navigate([], { relativeTo: this.route, queryParams: toParams(f) }); }
  apply() { this.go({ ...this.draft(), tab: this.applied().tab, sort: this.applied().sort, view: this.applied().view, page: 1 }); this.showFilters.set(false); }
  clear() { const a = this.applied(); this.go({ ...defaultFilters(), view: a.view, sort: a.sort }); }
  setTab(t: string) { this.go({ ...this.applied(), tab: t, page: 1 }); }
  setSort(s: string) { this.go({ ...this.applied(), sort: s, page: 1 }); }
  setView(v: 'grid' | 'list') { this.go({ ...this.applied(), view: v }); }
  setPage(n: number) { this.go({ ...this.applied(), page: n }); window.scrollTo({ top: 0, behavior: 'smooth' }); }
  search() { this.go({ ...this.applied(), q: this.draft().q.trim(), page: 1 }); }

  get activeCount() {
    const f = this.applied();
    return ARR.reduce((n, k) => n + f[k].length, 0) + (f.province ? 1 : 0) + (f.village ? 1 : 0) + (f.now ? 1 : 0) + (f.rate ? 1 : 0) + (f.q ? 1 : 0);
  }

  // ---- ảnh nhiều link ----
  imgs(p: ProductItem): string[] { return (p.images ?? []).filter(u => u && !this.brokenImg().has(u)); }
  idxOf(p: ProductItem) { const n = this.imgs(p).length; return n ? (this.imgIdx()[p.id] ?? 0) % n : 0; }
  cur(p: ProductItem) { return this.imgs(p)[this.idxOf(p)]; }
  step(p: ProductItem, d: number, e: Event) {
    e.stopPropagation();
    const n = this.imgs(p).length;
    this.imgIdx.update(m => ({ ...m, [p.id]: (this.idxOf(p) + d + n) % n }));
  }
  setImg(p: ProductItem, i: number, e: Event) { e.stopPropagation(); this.imgIdx.update(m => ({ ...m, [p.id]: i })); }
  imgError(url: string) { this.brokenImg.update(s => new Set(s).add(url)); }

  // ---- hiển thị ----
  fmt(n: number) { return n.toLocaleString('vi-VN') + 'đ'; }
  stars(r: number) { const n = Math.round(r); return '★'.repeat(n) + '☆'.repeat(5 - n); }
  toggleFav(id: number) { this.favs.update(s => { const t = new Set(s); t.has(id) ? t.delete(id) : t.add(id); return t; }); }
  addToCart(e: Event) { e.stopPropagation(); this.cart.add(); }
}